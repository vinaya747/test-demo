package com.refund.Refund;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RefundApplicationTests {

	@Test
	void contextLoads() {
	}

}
