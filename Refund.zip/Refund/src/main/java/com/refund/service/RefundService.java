package com.refund.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.refund.model.Refund;
import com.refund.repository.RefundRepository;

@Service
public class RefundService {
    private final RefundRepository refundRepository;
    
    public RefundService(RefundRepository refundRepository) {
        this.refundRepository = refundRepository;
    }
    
    public Refund createRefund(Refund refund) {
        // Perform any necessary validation or business logic
        return refundRepository.save(refund);
    }
    
    public Refund getRefundById(Long id) {
        return refundRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Refund not found"));
    }
    
    public List<Refund> getAllRefunds() {
        return refundRepository.findAll();
    }
    
    public Refund updateRefund(Refund refund) {
        // Perform any necessary validation or business logic
        return refundRepository.save(refund);
    }
    
    public void deleteRefund(Long id) {
        refundRepository.deleteById(id);
    }
}
